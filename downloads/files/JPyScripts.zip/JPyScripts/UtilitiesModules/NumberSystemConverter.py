# Extremely broken and unfinished.

print("\nThis is a number system converter. It can convert numbers from one number system to another.")
print("Supported number systems: Binary, Octal, Decimal, Hexadecimal")
print("Valid conversion commands:\n"
      "bin2oct, bin2dec, bin2hex\n"
      "oct2bin, oct2dec, oct2hex\n"
      "dec2bin, dec2oct, dec2hex\n"
      "hex2bin, hex2oct, hex2dec\n")
numSysType = ["bin2oct", "bin2dec", "bin2hex", "oct2bin", "oct2dec", "oct2hex", "dec2bin", "dec2oct", "dec2hex",
              "hex2bin", "hex2oct", "hex2dec"]

while True:
    userSystemInput = input("Enter conversion type: ")
    if userSystemInput != "" and userSystemInput in numSysType:
        while True:
            userNumberInput = input("Enter number to convert: ")
            if userNumberInput != "":
                while True:
                    match userSystemInput:
                        case "bin2oct":
                            print("Octal:", oct(int(userNumberInput)))
                        case "bin2dec":
                            print("Decimal:", int(userNumberInput, 2))
                        case "bin2hex":
                            print("Hexadecimal:", hex(int(userNumberInput, 2)))
                        case "oct2bin":
                            print("Binary:", bin(int(userNumberInput, 8)))
                        case "oct2dec":
                            print("Decimal:", int(userNumberInput, 8))
                        case "oct2hex":
                            print("Hexadecimal:", hex(int(userNumberInput, 8)))
                        case "dec2bin":
                            print("Binary:", bin(int(userNumberInput)))
                        case "dec2oct":
                            print("Octal:", oct(int(userNumberInput)))
                        case "dec2hex":
                            print("Hexadecimal:", hex(int(userNumberInput)))
                        case "hex2bin":
                            print("Binary:", bin(int(userNumberInput, 16)))
                        case "hex2oct":
                            print("Octal:", oct(int(userNumberInput, 16)))
                        case "hex2dec":
                            print("Decimal:", int(userNumberInput, 16))
                    break
    else:
        print("Enter a valid conversion type.")
        continue
