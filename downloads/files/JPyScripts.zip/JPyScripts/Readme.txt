JPyScripts
Welcome to the JPyScripts! This is a collection of scripts/utilities I made in Python.
Type 'help' for more info
Code by: @Joshboi
GitHub: github.com/swarnab1
Site: swarnab1.github.io

Note:
You might need to have some modules installed for this to work properly.

List of python modules used:
OS
Requests
Platform
HashLib
String
Random
WebBrowser


Commands:
Program commands:
fizzbuzz - FizzBuzz Test
rndnumprank - Random Number Prank
simplecalc - Simple Calculator
divcheck - Divisibility Check Program
myip - Returns your Public IP Address
search - Search using Google, Bing or DuckDuckGo
passgen - A simple password generator
tempconvert - Temperature Converter (Between Celsius and Fahrenheit)
hasher - String to MD5, SHA1, SHA256, SHA512 converter

Console commands:
exit - Exit the program
cls - Clear Screen
help - Commands info and list
pyversion - Returns your Python version
getos - Returns your Operating System info
about - About the program