-------------------------------------------
HAVE FUN EDITING THE MAP
-------------------------------------------

aim_frontline_snow, uploaded to workshop as aim_snowline.

Needed materials are included in the materials folder.

I will not be including radar, nav or any txt file.

Thanks to:
GMod Devs, Facepunch Studios, Garry Newman

Map created by JoshboiFPS
https://steamcommunity.com/id/JoshboiFPS/myworkshopfiles
https://github.com/swarnab1
https://swarnab1.github.io

Special note: Please credit me (JoshboiFPS) if you want to upload a modified version of this map. That's all you need to do.